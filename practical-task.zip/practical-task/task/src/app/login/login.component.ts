import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { AuthService } from 'src/app/global/services/authentication/auth.service';
import { TokenService } from 'src/app/global/services/authentication/token.service';
import { NgForm, FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginData: any = {
    email: '',
    password: '',
  }
  @ViewChild('loginForm') form: FormGroup;
  title: string = 'Login Page';
  submitForm: boolean = false;
 
  constructor(private auth: AuthService,private token: TokenService, private router: Router, private elementRef: ElementRef) { }

  ngOnInit() {
    // if (this.token.isLoggedIn()) {
    //   this.router.navigate(['/my-profile']);
    // }
  }

  submitLoginDetails() {
    this.submitForm = true;
    let data = {
      email:this.loginData.email,
      password:this.loginData.password
    }
    if (this.form.valid) {
       this.auth.login(this.loginData).subscribe(       
          response => this.handleResponse(response),
         (error) => this.handleError(error)       
       );
      
    } else { 
      
    }
  }

  handleResponse(response:any) {
    if (response.status) {
      this.token.handleToken(response.token);
      this.auth.changeAuthStatus(this.token.isLoggedIn(), this.token.userData());
      localStorage.removeItem('login_data');
      let userdata = this.token.userData();
      localStorage.setItem('login_data', JSON.stringify(userdata));
      console.log(userdata);

      Swal.fire('Successful', 'You have been logged in successfully.', 'success');
       this.router.navigate(['/user-details']);
    } else {      
      this.submitForm = false;
      Swal.fire('Request Failed!', 'Something went wrong. Please try again !!!', 'error');
    }
  }

  handleError(error:any) {
    if (error.error.loggedIn) {
      Swal.fire({
        title: 'Do you want to log out of your previous login?',
        text: error.error.message,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No'
      }).then((result) => {
        if (result.value) {             
              this.submitForm = false;
              this.submitLoginDetails();
              Swal.fire('Successful!', 'You have been logged out from your previous login session.');
        } else if (result.dismiss === Swal.DismissReason.cancel) {
          Swal.fire(
            'Cancelled',
            'Your previous login session is safe :)',
            'error'
          )
        }
      })
    } else {      
      this.submitForm = false;
      Swal.fire('Request Failed!', error.error.message, 'error');
    }
  } 

}
