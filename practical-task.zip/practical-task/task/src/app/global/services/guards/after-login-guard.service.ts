import { Injectable } from '@angular/core';

import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '../authentication/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AfterLoginGuardService implements CanActivate{

  loggedIn: boolean;	

  constructor(private auth: AuthService, private router: Router) {
     let token = this.auth.getToken();
     if(token){
        this.loggedIn = true;
     }
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
  	 
     if (this.loggedIn) { 
     	
     	return this.loggedIn; 
     }

      // Navigate to the login page with extras
      this.router.navigateByUrl('/login');
      return false;
   }

}
