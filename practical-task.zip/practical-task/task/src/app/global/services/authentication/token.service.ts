import { Injectable } from '@angular/core';

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TokenService {
 
 private iss = {
  	login: environment.apiBaseUrl+'/login',
  	signup: environment.apiBaseUrl+'/signup'
    };	

    constructor() { }

    handleToken(token:any) {
      this.set(token);
    }

    set(token:any) {
      localStorage.setItem('token', token);
    }

    get() {
      return localStorage.getItem('token');
    }

    userData() {
      const token = this.get();
      if(token){
        const payload = this.getPayload(token);
        if(payload){
          return payload.data;
        }
      }
    }
    remove() {
      localStorage.removeItem('token');
      localStorage.removeItem('userdata');
      localStorage.clear();
    }

    isValid() {
      const token = this.get();
      if(token){
        const payload = this.getPayload(token);
        if(payload) {
          const status = (Object.values(this.iss).indexOf(payload.iss) > -1 ) ? true : false;
          if(status === true) {
            return true;
          }
          return false;
        }
  	}

  	return false;
    }

    getPayload(token:any) {  	
      const payload = token.split('.')[1];
      if(payload){
        return JSON.parse(atob(payload));
      }
    }

    isLoggedIn() {
      return this.isValid();
    }

}
