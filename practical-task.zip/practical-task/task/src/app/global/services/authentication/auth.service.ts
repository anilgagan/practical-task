import { Injectable, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { TokenService } from './token.service';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private loggedInStatus: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.token.isLoggedIn());
  private loggedInUserData: BehaviorSubject<any> = new BehaviorSubject<any>(this.token.userData());

  //to handle expired token
  
  authStatus = this.loggedInStatus.asObservable();
  authUserData = this.loggedInUserData.asObservable();

  private apiBaseUrl = environment.apiBaseUrl;

  constructor(private token: TokenService, private router: Router, private http: HttpClient) { }

  changeAuthStatus(value: boolean, userUdata: any) {

    this.loggedInStatus.next(value);
    this.loggedInUserData.next(userUdata);
  }
  
  login(data:any) {

      return this.http.post(this.apiBaseUrl + 'admin/users/login', data);
  
  }
  logout() {
    this.token.remove();
    this.changeAuthStatus(false, {});
    this.router.navigate(['/login']);
  }  
  getToken() {
    return this.token.get();
  }
}
