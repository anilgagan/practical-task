import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from 'src/app/global/services/common/common.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgForm, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  baseURL = environment.imageBaseUrl;

  packageData: any = {
    title: '',
    website:'',
    shortCode:'',
    director:''
  }

  

  @ViewChild('userForm') form: FormGroup;
  submitForm: boolean = false;
  userList : any;

  constructor( private common: CommonService, private router: Router) { }
  
  ngOnInit(): void {
    this.getUserList();
  }


  getUserList(){
    this.common.getUserListing().subscribe( response => {
        this.userList = response.responseData;
      },
      (error:any) => this.handleError(error)
    );
  }
  chnageStatus(id:any, status:any){
    Swal.fire({
      title: 'Are you sure?',
      text: 'You want to change status of this user',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, change it!',
      cancelButtonText: 'No, keep it'
    }).then((result) => {
      if (result.value) {
        this.common.changeStatus({id:id, status:status}).subscribe(
          response => {            
            this.getUserList();
            Swal.fire(
              'Success!',
              'User status has been changed.',
              'success'
            )
          },
          (error) => this.handleError(error)
        );
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire(
          'Cancelled',
          'User is safe :)',
          'error'
        )
      }
    })
  }
  handleError(error:any) {
    if(error.error.password){
      error.error.message=error.error.password;
      Swal.fire('Password must be at least 6 characters !!!', '', 'error');
    } else if(error.error.password2){
      error.error.message=error.error.password2;
      Swal.fire('Paaaword not match !!!', '', 'error');
    }else{     
      Swal.fire('Request failed !!!', error.error.message, 'error');
    }
    
  }
  gotoProfile() {   
    this.router.navigate(['/my-profile']);
  }
  myFunction() {
    var input:any, filter:any, table:any, tr:any, td:any, i:any, txtValue:any;
    input = document.getElementById("myInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("myTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[3];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }       
    }
  
  }
}
