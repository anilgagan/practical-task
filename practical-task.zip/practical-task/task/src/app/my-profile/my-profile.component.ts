import { Component, OnInit, ViewChild } from '@angular/core';
import { AuthService } from 'src/app/global/services/authentication/auth.service';
import Swal from 'sweetalert2'
import { Router } from '@angular/router';
import { NgForm, FormGroup } from '@angular/forms';
import { CommonService } from 'src/app/global/services/common/common.service';
import { environment } from '../../environments/environment';


@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  
  baseURL = environment.imageBaseUrl;

  constructor(private auth: AuthService, private router: Router,private common:CommonService) { }
  isLoggedin:boolean = false;
  dynamicVariable:boolean  = true; 
  userData= {
    email:'',
    lastname:'',
    firstname:'',
    image:'',
    _id:''
  };
  
  
  @ViewChild('profileForm') form: FormGroup;
  
  submitForm:boolean= false;
  fileData1:File;
  fileData1Label: string;
  fileData1Error:boolean = false;
  sessionData:any;
  image: any;


  ngOnInit() {
    this.auth.authStatus.subscribe(value => this.isLoggedin = value);
    this.auth.authUserData.subscribe(value => this.sessionData = value);   
    this.getProfileData();
  }
  onFileSelect(event:any) {
    this.fileData1 = event.target.files[0];
    this.fileData1Label = this.fileData1.name;
    this.fileData1Error = false;
  }

  logoutuser() {
    Swal.fire('Successful!','You have been logged out succesfully.','success');
    this.auth.logout();
  }

  updateDetails() {    
    this.submitForm = true;    
    let data = {
      firstname : this.userData.firstname,
      image: this.fileData1,
      _id: this.userData._id,
      lastname:this.userData.lastname,
      email:this.userData.email
    }

    
    if (this.form.valid) {
      this.common.updateProfile(data).subscribe(     
        response => {
          this.handleResponse(response)
        },
        (error) => this.handleError(error)
      );
    } else {
    }
  }
  editDetails(value:any) {   
    this.dynamicVariable = value;
  }
  
  getProfileData(){    
    this.common.getUserDetail({id:this.sessionData._id}).subscribe(
      response => {
        this.userData = response.userdata;      
      },
      (error) => this.handleError(error)  
    )
  }

  handleResponse(response:any) {   
    this.submitForm=false;
    if(response.responseStatus){
      window.location.reload();
      Swal.fire('Successful!',response.responseMsgCode,'success');
      this.router.navigate(['/my-profile']);
    }else{
      Swal.fire('Process failed!',response.responseMsgCode,'error');
      this.router.navigate(['/my-profile']);
    }    
  }
  handleError(error:any) {
    this.submitForm=false;
    Swal.fire('Request failed !!!',"Something went wrong.",'error');
  }
  gotoUserDetail() {   
    this.router.navigate(['/user-details']);
  }
}

