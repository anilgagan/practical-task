import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AfterLoginGuardService } from 'src/app/global/services/guards/after-login-guard.service';

const routes: Routes = [
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule) }, 
  { path: 'signup', loadChildren: () => import('./signup/signup.module').then(m => m.SignupModule) }, 
  { path: 'my-profile', loadChildren: () => import('./my-profile/my-profile.module').then(m => m.MyProfileModule),canActivate: [AfterLoginGuardService] },
  { path: 'user-details', loadChildren: () => import('./user-details/user-details.module').then(m => m.UserDetailsModule)}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
