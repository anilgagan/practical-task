import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from 'src/app/global/services/common/common.service';
import { NgForm, FormGroup } from '@angular/forms';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupData: any = {
    firstname: '',
    lastname:'',
    email:'',
    password:'',
    password2:''
  }
  @ViewChild('signupForm') form: FormGroup;
  
  title: string = 'Signup Page';
  submitForm: boolean = false;
  fileData1:File;
  fileData1Label: string;
  fileData1Error:boolean = false;

  constructor( private common: CommonService, private router: Router, private elementRef: ElementRef) { }

  ngOnInit() {
  }
  onFileSelect(event:any) {
    this.fileData1 = event.target.files[0];
    this.fileData1Label = this.fileData1.name;
    this.fileData1Error = false;
  }
  submitLoginDetails() {    
    this.submitForm = true;
    let data = {
      firstname : this.signupData.firstname,
      image: this.fileData1,
      lastname:this.signupData.lastname,
      email:this.signupData.email,
      password:this.signupData.password,
      password2:this.signupData.password2
    }

    if (this.form.valid) {
      this.common.saveSignup(data).subscribe(     
        response => {
          this.handleResponse(response)
        },
        (error) => this.handleError(error)
      );
    } else {
     
    }
  }
  handleResponse(response:any) {   
    //console.log(response);   
   
    if(response.responseStatus=="1"){
      this.form.reset();
      this.submitForm = false;
      this.fileData1Label = "";
      this.fileData1Error = true;
      this.router.navigate(['/login']);
      Swal.fire('Successful!', response.responseMsgCode, 'success');
    }else{
      Swal.fire('Invalid Request!!', response.responseMsgCode, 'warning');
    }
  }
  handleError(error:any) {
    if(error.error.password){
      error.error.message=error.error.password;
      Swal.fire('Password must be at least 6 characters !!!', '', 'error');
    } else if(error.error.password2){
      error.error.message=error.error.password2;
      Swal.fire('Paaaword not match !!!', '', 'error');
    }else{     
      Swal.fire('Request failed !!!', error.error.message, 'error');
    }
    
  }
}
