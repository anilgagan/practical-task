const express = require('express');
const router = express.Router();
router.use('/users', require('./controllers/login.controller'));
router.use('/signupUser', require('./controllers/users.controller'));
module.exports = router;