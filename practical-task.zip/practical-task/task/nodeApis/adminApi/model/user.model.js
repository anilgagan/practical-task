﻿var config = require('config.json');
var bcrypt = require('bcryptjs');
var Q = require('q');
var ObjectId = require('mongodb').ObjectID;
var MongoClient = require('mongodb').MongoClient;
var db;
MongoClient.connect(config.connection, { useNewUrlParser: true, useUnifiedTopology: true }, function (err, dbo) {
	if (err) throw err;
	db = dbo.db(config.dbname);
	// dbo.close();
});


var service = {};

//User Profiles
service.savesignup = saveSignup;
service.updateProfile=updateProfile;
service.getUserListing=getUserListing;
service.getChangeStatus=getChangeStatus;

module.exports = service;

function saveSignup(getParams){
	var deferred = Q.defer();
	//console.log('----model---------------');
	//console.log(getParams); return false;
	
	var _data = {
		"firstname":getParams.firstname,				 
		"image":getParams.image,
		"lastname":getParams.lastname,
		"status":1,
		"email":getParams.email,
		"password":bcrypt.hashSync(getParams.password, 10),
		"add_on": new Date()
	}

	db.collection("tbl_users").findOne({ email: getParams.email }, function (err, data) {
		if (data != null) {					
			deferred.resolve({ status: false, message: 'Email can not be duplicate. Please change it.' });
		}else{
			db.collection("tbl_users").insertOne(_data, function(err, doc) {
				if (err)
					deferred.reject(err.name + ': ' + err.message);
				if(doc){
					deferred.resolve({ success: true, message: 'User added successfully' });
				}else{
					deferred.resolve();
				}
				
			});
		} 
	})
	
	return deferred.promise;

}
function updateProfile(getParams){
	
	var deferred = Q.defer();
	
	// console.log('========================');
	// console.log(getParams); return false;
	if(typeof getParams.image ===undefined){
		var data = {
			"firstname":getParams.firstname,				 
			"lastname":getParams.lastname,
			"email":getParams.email,			
			"update_on": new Date()
		}
	}else{
		var data = {
			"firstname":getParams.firstname,				 
			"image":getParams.image,
			"lastname":getParams.lastname,
			"email":getParams.email,			
			"update_on": new Date()
		}
	}
	if(getParams._id){
	
		db.collection('tbl_users').updateOne({ _id: ObjectId(getParams._id) }, { $set: data }, function (err, data) {
			
			if (err) deferred.reject(err.name + ': ' + err.message);
			if (data) {
				deferred.resolve({ status: true, message: 'Profile updated successfully' });
			} else {
				deferred.resolve();
			}
		});
		
	}else{
		deferred.resolve();
	}
	return deferred.promise;


}
function getUserListing(){
	var deferred = Q.defer();

	db.collection("tbl_users").find({}).sort( { "_id": -1 } ).toArray(function (err, data) {
		if (err)
			deferred.reject(err.name + ': ' + err.message);
		if (data != null) {
			deferred.resolve(data);
		} else {
			deferred.resolve('');
		}

	});
	return deferred.promise;
}
function getChangeStatus(getParams) {
	var deferred = Q.defer();
	var id = ObjectId(getParams.id);
	let status = (getParams.status==1)?0:1; 
	
	db.collection('tbl_users').updateOne({ _id: id },{$set:{status:status}}, function (err, data) {
		if (err) deferred.reject(err.name + ': ' + err.message);
		if (data) {
			deferred.resolve(data);
		} else {
			deferred.resolve();
		}
	});
	
	return deferred.promise;
}