const express = require('express');
const router = express.Router();
const path = require('path');
var multer = require('multer');
var userModel = require('adminApi/model/user.model');
const validateRegisterInput = require('../validation/register');
const config = require('config.json');
var jwt = require('jsonwebtoken');

 //Profile Storage
var storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, path.join(`${__dirname}/../../public/user`))		
	},
	filename: function (req, file, cb) {
		let filename = file.originalname.replace(" ", "-");
		cb(null, Date.now() + '-' + filename)
	}
});
var upload = multer({ storage: storage });


router.post('/saveSignup', upload.fields([{ name: 'image', maxCount: 1 }, { name: 'selectedImage', maxCount: 1 }]), saveSignup);
router.post('/updateprofile', upload.fields([{ name: 'image', maxCount: 1 }, { name: 'selectedImage', maxCount: 1 }]), updateProfile);
router.get('/getUserListing',getUserListing);
router.post('/changeStatus',changeStatus);

module.exports = router;

function saveSignup(req, res) {	
	
		const { errors, isValid } = validateRegisterInput(req.body);
		if (!isValid) {
			res.status(400).json(errors);
		}else{

			if(req.files){
				req.body.image = req.files.image[0].filename
			}else{
				req.body.image=''; 
			}		
			if(req.body.image==""){
				return res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Image is mandatory to upload.", "responseInvalid": 0 });
			}		
		userModel.savesignup(req.body).then(function (signupdata) {
			data = {}
			if (signupdata) {
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": signupdata.message, "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": signupdata.message, "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log('13/11/2021')
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
		})

		}
	
}
function updateProfile(req, res) {
	
	try {
		if(req.files.image && req.files.image!=undefined){
			req.body.image = req.files.image[0].filename;
		}else{
			delete req.body.image; 
		}	
		userModel.updateProfile(req.body).then(function (profiles) {
			data = {}
			if (profiles) {
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": profiles.message, "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong while updating details.", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}

function getUserListing(req, res) {

	try {
		userModel.getUserListing(req.body).then(function (Userdata) {
			data = {}
			if (Userdata) {
				data = Userdata;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "userDataFetched", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "noDataAvailable", "responseInvalid": 0 });
			}
		}).catch(function (err) {
				// console.log(err);
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseInvalid": 0 });
			})


	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "processFailed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}

function changeStatus(req, res) {

	try {
		userModel.getChangeStatus(req.body).then(function (userstatus) {
			data = {}
			if (userstatus) {
				data = userstatus;
				res.status(200).send({ "responseStatus": 1, "responseMsgCode": "User status changed successfully.", "responseData": data, "responseInvalid": 0 });
			} else {
				res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Something went wrong.", "responseInvalid": 0 });
			}
		}).catch(function (err) {
			// console.log(err);
			res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseInvalid": 0 });
		})

	} catch (error) {
		res.status(200).send({ "responseStatus": 0, "responseMsgCode": "Process Failed", "responseData": { "err": error }, "responseInvalid": 0 });
	}

}
