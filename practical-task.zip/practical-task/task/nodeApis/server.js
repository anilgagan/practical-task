require('rootpath')();
const Express = require("express");
const bodyParser = require("body-parser");
const path = require('path');
const http = require('http');
var config = require('config.json');
var session = require('express-session');

var app = Express();

const passport = require('passport');

app.use(bodyParser.urlencoded({ limit: '50mb', extended: true, parameterLimit: 1000000 }));
app.use(bodyParser.json());
app.use(session({ secret: config.secret, resave: false, saveUninitialized: true ,cookie:{maxAge:60000}}));
var cors = require('cors');

app.use(cors({ origin: 'http://localhost:4200' }));

app.use(function (req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");  //* will allow from all cross domain
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
	next();
});


app.use(Express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());

app.use('/admin', require('./adminApi/api'));


process.env['TZ'] = 'UTC';

//process.env['NODE_ENV'] = 'development';
process.env['NODE_ENV'] = 'production';

// used in production

if (process.env.NODE_ENV === 'production') {
	app.use(Express.static('client/build'));
	app.get('*', (req, res) => {
		//res.sendFile(path.join(__dirname, 'public/admin/index.html'));
	});
	// app.get('*', (req, res) => {
	//    res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'));
	// });
}

const port = process.env.PORT || '8081';
app.set('port', port);

const server = http.createServer(app);

server.listen(port, () => console.log(`Running on server:${port}`));